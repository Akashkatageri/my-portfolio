export default function About() {
  const stats = [
    { label: "Experience", value: "5+ Years" },
    { label: "Location", value: "San Francisco, CA" },
    { label: "Projects", value: "50+ Completed" },
    { label: "Clients", value: "25+ Happy" },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">About Me</h2>
          <p className="text-slate-600 text-lg max-w-3xl mx-auto">
            Passionate developer with a love for clean code and innovative solutions
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-slate-900">Hello! I'm Akash Katageri</h3>
            <p className="text-slate-600 leading-relaxed">
              I'm a passionate Full Stack Developer with over 5 years of experience creating digital experiences that combine beautiful design with solid functionality. I specialize in React, Node.js, and modern web technologies.
            </p>
            <p className="text-slate-600 leading-relaxed">
              When I'm not coding, you can find me exploring new technologies, contributing to open source projects, or enjoying a good cup of coffee while reading about the latest trends in web development.
            </p>
            
            <div className="grid grid-cols-2 gap-6 pt-6">
              {stats.map((stat, index) => (
                <div key={index}>
                  <h4 className="font-semibold text-slate-900 mb-2">{stat.label}</h4>
                  <p className="text-slate-600">{stat.value}</p>
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex justify-center">
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=600" 
              alt="John Smith - Professional Developer Portrait" 
              className="rounded-2xl shadow-xl w-80 h-96 object-cover object-center"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
