import type { SkillCategory } from "@/lib/types";

export default function Skills() {
  const skillCategories: SkillCategory[] = [
    {
      title: "Frontend Development",
      icon: "fas fa-code",
      skills: [
        { name: "React", icon: "fab fa-react" },
        { name: "JavaScript", icon: "fab fa-js-square" },
        { name: "CSS", icon: "fab fa-css3-alt" },
        { name: "HTML5", icon: "fab fa-html5" },
        { name: "Sass", icon: "fab fa-sass" },
        { name: "Bootstrap", icon: "fab fa-bootstrap" },
      ]
    },
    {
      title: "Backend Development",
      icon: "fas fa-server",
      skills: [
        { name: "Node.js", icon: "fab fa-node-js" },
        { name: "Python", icon: "fab fa-python" },
        { name: "MongoDB", icon: "fas fa-database" },
        { name: "PostgreSQL", icon: "fas fa-database" },
        { name: "Firebase", icon: "fas fa-fire" },
        { name: "REST API", icon: "fas fa-code-branch" },
      ]
    },
    {
      title: "Tools & DevOps",
      icon: "fas fa-tools",
      skills: [
        { name: "Git", icon: "fab fa-git-alt" },
        { name: "Docker", icon: "fab fa-docker" },
        { name: "AWS", icon: "fab fa-aws" },
        { name: "Linux", icon: "fab fa-linux" },
        { name: "CI/CD", icon: "fas fa-cloud" },
        { name: "npm", icon: "fab fa-npm" },
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-slate-900 mb-4">Skills & Expertise</h2>
          <p className="text-slate-600 text-lg max-w-3xl mx-auto">
            Technologies and tools I work with to bring ideas to life
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => (
            <div key={index} className="bg-white p-8 rounded-xl shadow-lg">
              <div className="text-center mb-6">
                <i className={`${category.icon} text-4xl text-primary mb-4`}></i>
                <h3 className="text-xl font-semibold text-slate-900">{category.title}</h3>
              </div>
              <div className="grid grid-cols-3 gap-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="text-center">
                    <i className={`${skill.icon} skill-icon text-3xl text-slate-600 mb-2 hover:text-primary transition-all duration-300`}></i>
                    <p className="text-sm text-slate-600">{skill.name}</p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
