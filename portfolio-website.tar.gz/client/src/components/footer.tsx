export default function Footer() {
  const socialLinks = [
    { icon: "fab fa-github", href: "https://github.com", label: "GitHub" },
    { icon: "fab fa-linkedin", href: "https://linkedin.com", label: "LinkedIn" },
    { icon: "fab fa-twitter", href: "https://twitter.com", label: "Twitter" },
    { icon: "fab fa-instagram", href: "https://instagram.com", label: "Instagram" },
    { icon: "fas fa-envelope", href: "mailto:john.smith@email.com", label: "Email" },
  ];

  return (
    <footer className="bg-slate-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4">John Smith</h3>
          <p className="text-slate-300 mb-6">
            Full Stack Developer passionate about creating amazing digital experiences
          </p>
          
          <div className="flex justify-center space-x-6 mb-8">
            {socialLinks.map((link, index) => (
              <a
                key={index}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-300 hover:text-white text-xl transition-colors duration-300"
                aria-label={link.label}
              >
                <i className={link.icon}></i>
              </a>
            ))}
          </div>
          
          <div className="border-t border-slate-600 pt-8">
            <p className="text-slate-400 text-sm">
              © 2024 John Smith. All rights reserved. Built with ❤️ using modern web technologies.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
