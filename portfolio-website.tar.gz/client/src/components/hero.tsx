import { Button } from "@/components/ui/button";

export default function Hero() {
  const handleNavClick = (sectionId: string) => {
    const section = document.getElementById(sectionId);
    if (section) {
      const navHeight = 64;
      const targetPosition = section.offsetTop - navHeight;
      
      window.scrollTo({
        top: targetPosition,
        behavior: "smooth"
      });
    }
  };

  const socialLinks = [
    { icon: "fab fa-github", href: "https://github.com", label: "GitHub" },
    { icon: "fab fa-linkedin", href: "https://linkedin.com", label: "LinkedIn" },
    { icon: "fab fa-twitter", href: "https://twitter.com", label: "Twitter" },
    { icon: "fab fa-instagram", href: "https://instagram.com", label: "Instagram" },
    { icon: "fas fa-envelope", href: "mailto:john.smith@email.com", label: "Email" },
  ];

  return (
    <section id="home" className="gradient-bg min-h-screen flex items-center justify-center text-white pt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Hi, I'm <span className="text-accent">John Smith</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
            Full Stack Developer passionate about creating beautiful, functional web applications that make a difference.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={() => handleNavClick("projects")}
              className="bg-white text-slate-800 px-8 py-3 rounded-lg font-semibold hover:bg-slate-100 transition-colors duration-300"
              size="lg"
            >
              <i className="fas fa-folder-open mr-2"></i>View My Work
            </Button>
            <Button
              onClick={() => handleNavClick("contact")}
              variant="outline"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-slate-800 transition-colors duration-300"
              size="lg"
            >
              <i className="fas fa-envelope mr-2"></i>Get In Touch
            </Button>
          </div>
          
          {/* Social Links */}
          <div className="flex justify-center space-x-6 mt-12">
            {socialLinks.map((link, index) => (
              <a
                key={index}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-200 hover:text-white text-2xl transition-colors duration-300"
                aria-label={link.label}
              >
                <i className={link.icon}></i>
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
